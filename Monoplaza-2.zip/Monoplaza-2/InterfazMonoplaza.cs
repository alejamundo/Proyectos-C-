namespace Monoplaza;

public interface InterfazMonoplaza
{
    public void Encender();
    public void Apagar();
    public void Detener();
    public void Mover();
}