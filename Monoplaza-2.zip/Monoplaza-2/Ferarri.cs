namespace Monoplaza;

public class Ferarri : MonoplazaAbstract
{
    string escuderia;
    public Ferarri(string escuderia) : base(escuderia)
    {
        this.escuderia=escuderia;
    }
}