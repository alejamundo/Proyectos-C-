namespace Monoplaza;

public class Mclaren : MonoplazaAbstract
{
    string escuderia;
    public Mclaren(string escuderia) : base(escuderia)
    {
        this.escuderia=escuderia;
    }
}