namespace Monoplaza;

public class Redbul : MonoplazaAbstract
{
    string escuderia;
    public Redbul(string escuderia) : base(escuderia)
    {
        this.escuderia=escuderia;
    }
}