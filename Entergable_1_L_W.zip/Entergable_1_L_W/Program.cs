﻿//Entregable 1-L-W
//Presentado por: Alejandra Orrego, Cristian rios, yureixon , Juan garcia.

//Menu con los 4 Ejercicios

int opc = 0;
String menu = "\n1) Ejercicio 1  La renta\n"
+ "2) Ejercicio 2 Sala de juegos\n"
+ "3) Ejercicio 3 La pizzería\n"
+ "4) Ejercicio 4 Empleados premiados\n"
+ "0) Salir del sistema\n";
do
{
    Console.WriteLine("\nIngresa una opción\n" + menu);
    opc = Int32.Parse(Console.ReadLine());
    switch (opc)
    {
        case 1://realizado por yureixon 
            int[] valoresT = new int[4];
            int suma = 0;
            double impuesto = 0;

            for (int i = 0; i <= valoresT.Length - 1; i++)
            {
                Console.WriteLine("");
                Console.WriteLine("Ingrese Valor del Trimestre: " + (i + 1));
                valoresT[i] = Int32.Parse(Console.ReadLine());
                suma = suma + valoresT[i];
                Console.WriteLine("");
            }

            if (suma < 10000)
            {
                impuesto = 0.05;
            }

            if (suma >= 10000 && suma < 20000)
            {
                impuesto = 0.1;
            }

            if (suma >= 20000 && suma < 35000)
            {
                impuesto = 0.15;
            }

            if (suma >= 35000 && suma < 45000)
            {
                impuesto = 0.2;
            }

            if (suma > 45000)
            {
                impuesto = 0.3;
            }
            Console.WriteLine("*****************************************");
            Console.WriteLine("Renta Anual: " + suma + "\nTotal Renta a pagar: "
            + (/*suma+*/(suma * impuesto)) + "\nPorcentaje de Impuesto agregado: "
            + impuesto * 100 + "%"/*+"Equivalente a: "+suma*impuesto*/);
            Console.WriteLine("*****************************************");
            break;
        case 2://realizado por Cristian 
            Console.WriteLine("");
            Console.WriteLine("Ingrese su nombre completo: ");
            string nombreCompleto = Console.ReadLine();
            Console.WriteLine("Ingrese su edad: ");
            int edad = int.Parse(Console.ReadLine());

            double precioEntrada = 15000;
            double descuento = 0;
            if (edad < 4)
            {
                precioEntrada = 0;
            }
            else if (edad >= 4 && edad <= 18)
            {
                descuento = 0.05;
            }
            else
            {
                descuento = 0.03;
            }
            precioEntrada = precioEntrada - (precioEntrada * descuento);

            Console.WriteLine("*****************************************");
            Console.WriteLine("Nombre completo: " + nombreCompleto);
            Console.WriteLine("Precio de la entrada: " + precioEntrada);
            Console.WriteLine("Descuento: " + descuento * 100 + "%");
            Console.WriteLine("*****************************************");
            break;
        case 3://realizado por Juan
            Console.WriteLine("Ejercicio3");
            break;
        case 4://realizado por Alejandra
            Console.WriteLine("");
            float puntos = 0;
            String nivel = "";
            bool cumple = false;
            int BONO = 50000;

            do
            {
                Console.WriteLine("Ingresa Los puntos que gano el empleado por su rendimiento: ");
                puntos = float.Parse(Console.ReadLine());
                switch (puntos)
                {
                    case 0.0f:
                        nivel = "Inaceptable";
                        cumple = true;
                        break;
                    case 0.4f:
                        nivel = "Aceptable";
                        cumple = true;
                        break;
                    case 0.6f:
                        nivel = "Meritorio";
                        cumple = true;
                        break;
                    default:
                        Console.WriteLine("\nLos puntos validos" +
                        " para la evaluación son: 0,0--0,4-- y 0,6.");
                        cumple = false;
                        break;
                }
            } while (!cumple);//Cuando cumpla las condiciones

            Console.WriteLine("");
            Console.WriteLine("*****************************************");
            Console.WriteLine("Tu nivel de Evaluación es: " + nivel + "\nLa bonificación ganada" +
            " Por tu rendimiento es: " + Math.Round(BONO * puntos));
            Console.WriteLine("*****************************************");
            break;
        case 0://realizado por Alejandra
            Environment.Exit(0);
            break;

        default:
            Console.WriteLine("Opción No disponible, Intentelo de nuevo");
            break;
    }
} while (true);