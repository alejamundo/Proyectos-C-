namespace App_Semilleros
{
    class Profesor : Persona
    {
        private string nombre;
        private int id_facultad;
        private string especialidad;
        private string correo;


        //Método constructor para inicializar 
        public Profesor(string nombre, int id_facultad, string especialidad, string correo)
        {
            this.nombre = nombre;
            this.id_facultad = id_facultad;
            this.especialidad = especialidad;
            this.correo = correo;
        }

        //Métodos Get y set de la clase Porfesor
        public void SetEspecialidad(string espe)
        {
            this.especialidad = espe;
        }

        public string GetEspecialidad()
        {
            return especialidad;
        }
        public void SetCorreo(string correo)
        {
            this.correo = correo;
        }

        public string GetCorreo()
        {
            return correo;
        }


        //Metodos establecidos en La interfaz Persona

        public string GetNombre()
        {
            throw new NotImplementedException();
        }
        public void SetNombre(string nombre)
        {
            this.nombre = nombre;
        }

        public int GetFacultad()
        {
            return this.id_facultad;
        }

        public void SetFacultad(int id_facultad)
        {
            this.id_facultad = id_facultad;
        }


        public override string ToString()
        {
            return "Tu porfesor es: " + nombre+ "; este es su correo: " +
              correo;
        }

    }
}