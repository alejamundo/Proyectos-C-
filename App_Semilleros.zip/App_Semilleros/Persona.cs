namespace App_Semilleros
{
    interface Persona

    {
       string GetNombre();
        void SetNombre(string nombre);
         int GetFacultad();
         void SetFacultad(int id_facultad);

    }
}