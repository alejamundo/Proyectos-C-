namespace App_Semilleros

{
    class Semillero
    {
        private int id_facultad;
        private string nombre_Semillero;
        private string descripcion;
        private string horarios;

        public Semillero(int id_facultad, string nombre_Semillero, string descripcion, string horarios)
        {
            this.id_facultad = id_facultad;
            this.nombre_Semillero = nombre_Semillero;
            this.descripcion = descripcion;
            this.horarios = horarios;
        }

        //getter and setter;
        public int La_facultad { get => id_facultad; set => id_facultad = value; }
        public string Nombresemillero { get => nombre_Semillero; set => nombre_Semillero = value; }
        public string La_descripcion { get => descripcion; set => descripcion = value; }
        public string Los_Horarios { get => horarios; set => horarios = value; }

    //sobreescribo el metodo Tostring para mostrar la info de cada semilllero
        public override string ToString()
        {
            return "Semillero de investigación: "+nombre_Semillero+" el cual trata de : "+
            descripcion+" \nEstos son los Horarios: "+horarios;
        }

    }
}