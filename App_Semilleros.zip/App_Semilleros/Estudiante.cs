namespace App_Semilleros{


class Estudiante: Persona
{
    private string nombre;
    private int id_facultad;
    private int semestre;
    private string semillero_inscripcion;

    //Método constructor por default
    public Estudiante()
    {
    }

    //Métodos get y set de la clase estudiante
    public string inscripto{ get => semillero_inscripcion; set => semillero_inscripcion = value; }
    public void SetSemestre(int semestre){
        this.semestre=semestre;
    }
    public int GetSemestre(){
        return this.semestre;
    }

    //Metodos establecidos en La interfaz Persona
    public int GetFacultad()
    {
        return this.id_facultad;
    }

    public string GetNombre()
    {
       return this.nombre;
    }

    public void SetFacultad(int id_facultad)
    {
        this.id_facultad=id_facultad;
    }

    public void SetNombre(string nombre)
    {
        this.nombre=nombre;
    }

}
}