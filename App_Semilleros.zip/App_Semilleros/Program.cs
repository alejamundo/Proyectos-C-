﻿namespace App_Semilleros
{
    class Program
    {
        static void Main(string[] arg)
        {

            //Creacion de los semilleros disponibles
            Semillero semillero2 = new Semillero(3, "Seguridad SI", "Investigaciones enfocadas en seguridad de la red", "Jueves 1-3 salon: 5-107");
            Semillero semillero3 = new Semillero(1, "AUTOMATA", "Investigaciones enfocadas en la económia digital", "Miercoles 10-12 salon: 13-118");
            Semillero semillero4 = new Semillero(2, "FORES", "Investigaciones enfocadas en la medicina forence", "Sabados 10-12 salon: 10-118");
            Semillero semillero5 = new Semillero(4, "PSIO", "Investigaciones enfocadas en la psicologia", "Martes 10-12 salon: 13-210");
            Semillero semillero6 = new Semillero(5, "GISS", "Investigaciones enfocadas en las Teorias Cientificas", "Lunes 2-4 salon: 1-118");

            //Crearemos los profesores que hacen parte de los semilleros
            var profe2 = new Profesor("Yeiler Quintero", 3, "Ciber seguridad", "yquinter@tdea.edu.co");
            var profe3 = new Profesor("Sara Cruz", 2, "Lo forense", "sara@tdea.edu.co");
            var profe4 = new Profesor("Laura Vazques", 1, "Económia", "lauva@tdea.edu.co");
            var profe5 = new Profesor("Rogelio Rios", 4, "Educación", "Rogelio@tdea.edu.co");
            var profe6 = new Profesor("Stiven Vazques", 5, "Ciencias", "StivenV@tdea.edu.co");

            //Proseso de inscripción de los estudiantes
            Console.WriteLine("************************************");
            Console.WriteLine("Bienvenido a la APP de Inscripción a los semilleros de Investigación del TDEA");

            Estudiante alum1 = new Estudiante();
            Console.WriteLine("Por favor Ingrese su nombre:");
            alum1.SetNombre(Console.ReadLine());
            Console.WriteLine("¿En que semestre estas?");
            alum1.SetSemestre(Int32.Parse(Console.ReadLine()));
            Console.WriteLine("Indica el Id de la falcultad a la que perteneces:\n" +
            "1) Facultad de Ciencias Administrativas\n" +
            "2) Facultad de Derecho\n" +
            "3) Facultad de Ingeniería\n" +
            "4) Facultad de Educación\n" +
            "5) Facultad de Ciencias Básicas");
            alum1.SetFacultad(Int32.Parse(Console.ReadLine()));
            Console.WriteLine("************************************");
            Console.WriteLine("Acontinuación se mostraran los Semilleros disponibles en tu Facultad:");

            int desicion;//1=si 2=no
            switch (alum1.GetFacultad())
            {
                case 1:
                    //muestro los semilleros disponibles segun la facultad
                    Console.WriteLine(semillero3.ToString());
                    Console.WriteLine("¿Deseas Inscribirte a este semillero? Ingresa (1) para SI, ó (2) para NO");
                    desicion = Int32.Parse(Console.ReadLine());
                    if (desicion == 1)
                    {
                        Console.WriteLine("***************************************");
                        Console.WriteLine("Hola " + alum1.GetNombre() + " Quedaste Inscripta en\n" +
                        semillero3.ToString() + " y\n*****************************\n" + profe4.ToString());
                    }
                    else if (desicion == 2)
                    {
                        Console.WriteLine("Gracias por usar nuestra App");

                    }
                    else
                    {
                        Console.WriteLine("Opción invalida 1=si,2=no");
                    }
                    break;
                case 2:
                    Console.WriteLine(semillero4.ToString());
                    Console.WriteLine("¿Deseas Insrcribirte a este semillero? Ingresa (1 para SI, ó 2 para NO)");
                    desicion = Int32.Parse(Console.ReadLine());
                    if (desicion == 1)
                    {
                        Console.WriteLine("***************************************");
                        Console.WriteLine("Hola " + alum1.GetNombre() + " Quedaste Inscripta en\n" +
                        semillero4.ToString() + " y\n*****************************\n" + profe3.ToString());
                    }
                    else if (desicion == 2)
                    {
                        Console.WriteLine("Gracias por usar nuestra App");

                    }
                    else
                    {
                        Console.WriteLine("Opción invalida 1=si,2=no");
                    }
                    break;
                case 3:
                    Console.WriteLine(semillero2.ToString());
                    Console.WriteLine("¿Deseas Insrcribirte a este semillero? Ingresa (1 para SI, ó 2 para NO)");
                    desicion = Int32.Parse(Console.ReadLine());
                    if (desicion == 1)
                    {
                        Console.WriteLine("***************************************");
                        Console.WriteLine("Hola " + alum1.GetNombre() + " Quedaste Inscripta en\n" +
                        semillero2.ToString() + " y\n*****************************\n" + profe2.ToString());
                    }
                    else if (desicion == 2)
                    {
                        Console.WriteLine("Gracias por usar nuestra App");

                    }
                    else
                    {
                        Console.WriteLine("Opción invalida 1=si,2=no");
                    }
                    break;
                case 4:
                    Console.WriteLine(semillero5.ToString());
                    Console.WriteLine("¿Deseas Insrcribirte a este semillero? Ingresa (1 para SI, ó 2 para NO)");
                    desicion = Int32.Parse(Console.ReadLine());
                    if (desicion == 1)
                    {
                        Console.WriteLine("***************************************");
                        Console.WriteLine("Hola " + alum1.GetNombre() + " Quedaste Inscripta en\n" +
                        semillero5.ToString() + " y\n*****************************\n" + profe5.ToString());
                    }
                    else if (desicion == 2)
                    {
                        Console.WriteLine("Gracias por usar nuestra App");

                    }
                    else
                    {
                        Console.WriteLine("Opción invalida 1=si,2=no");
                    }
                    break;
                case 5:
                    Console.WriteLine(semillero6.ToString());
                    Console.WriteLine("¿Deseas Insrcribirte a este semillero? Ingresa (1 para SI, ó 2 para NO)");
                    desicion = Int32.Parse(Console.ReadLine());
                    if (desicion == 1)
                    {
                        Console.WriteLine("***************************************");
                        Console.WriteLine("Hola " + alum1.GetNombre() + " Quedaste Inscripta en\n" +
                        semillero6.ToString() + " y\n*****************************\n" + profe6.ToString());
                    }
                    else if (desicion == 2)
                    {
                        Console.WriteLine("Gracias por usar nuestra App");

                    }
                    else
                    {
                        Console.WriteLine("Opción invalida 1=si,2=no");
                    }
                    break;
                default:
                    Console.WriteLine("Facultad invalida: Intentelo nuevamente");
                    break;
            }




        }
    }
}
