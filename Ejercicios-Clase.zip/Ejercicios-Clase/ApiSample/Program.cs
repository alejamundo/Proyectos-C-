var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

List<Todo> BDMemory = new List<Todo>();
Todo todo = new Todo();
todo.Id = 1;
todo.Nombre = "Sacar basura";
todo.Completada = false;

Todo todo_2 = new Todo();
todo_2.Id = 2;
todo_2.Nombre = "Sacar al Perro";
todo_2.Completada = false;

BDMemory.Add(todo);
BDMemory.Add(todo_2);

app.MapGet("/api/v1/todo", () => {
    return Results.Ok(BDMemory);
});

app.MapGet("/api/v1/todo/{id}", (int id) => {
    return Results.Ok(BDMemory.Single(todo => todo.Id == id));
});

app.MapPost("/api/v1/todo/", (Todo todo) => {
    BDMemory.Add(todo);
    return Results.Ok(BDMemory);
});

app.MapPut("/api/v1/todo/{id}", (Todo todo, int id) => {
    Todo todoBd = BDMemory.Single(todo => todo.Id == id);
    todoBd.Nombre = todo.Nombre;
    todoBd.Completada = todo.Completada;
    return  Results.Ok(BDMemory);
    });

app.MapDelete("/api/v1/todo/{id}", (int id) => {
    BDMemory.RemoveAll(todo => todo.Id == id); 
    return  Results.Ok(BDMemory);
    });

app.Run();

class Todo
{
    public int Id { get; set;}
    public string Nombre { get; set;}
    public bool Completada { get; set;}
}