namespace clase1;

public class CarroDTO
{

    public int Id { get; set; }
    public string Nombre { get; set; }
    public int Modelo { get; set; }
    public string Color { get; set; } 


}