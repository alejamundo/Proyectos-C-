namespace clase1;


public class Carro
{

    private List<CarroDTO> BD;

    public Carro()
    {
        this.BD = new List<CarroDTO>();
    }

    public void Add(CarroDTO carro)
    {
        this.BD.Add(carro);
    }

    public void AddAll(CarroDTO[] Carros){
       

        foreach(CarroDTO carro in Carros){
            this.Add(carro);
        }
    }

    public void Delete(int id)
    {
        this.BD.RemoveAll(carro => carro.Id == id);
    }

    public void update(int id, CarroDTO carro)
    {
        CarroDTO carroUpdate = this.BD.Single(carro => carro.Id == id);
        carroUpdate = carro;

    }

    public List<CarroDTO> All()
    {
        return this.BD;
    }


}