using clase1;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

//Entidad carro: Nombre, Modelo, Color.

Carro carro = new Carro();

app.MapPost("/api/v1/carro", (CarroDTO carroDTO) =>
{
  carro.Add(carroDTO);
});

app.MapPost("/api/v1/lista", (CarroDTO[] carroDTO) =>
{
  carro.AddAll(carroDTO);
});

app.MapGet("/api/v1/carro", () => {
  return Results.Ok(carro.All());
});



app.Run();



// {
//     "Nombre": "Mazda";
//     "Modelo": 2023;
//     "Color": "Rojo";
// }
/*
{
  "id": 1,
    "Nombre": "Mazda",
    "Modelo": 2023,
    "Color": "Rojo"
}
*/