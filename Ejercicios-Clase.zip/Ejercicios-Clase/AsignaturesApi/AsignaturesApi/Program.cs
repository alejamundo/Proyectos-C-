var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

List<EstudianteMateriaseDTO> DB = new List<EstudianteMateriaseDTO>();

app.MapPost("/api/v1/estudiante/materias", (EstudianteMateriaseDTO esDto) => {
    DB.Add(esDto);
});

app.MapGet("/api/v1/estudiante/materias", () => {
    return Results.Ok(DB);
});

app.MapPut("/api/v1/estudiante/{id}/materias", (int id, EstudianteMateriaseDTO esDto) => {
    // Select * FROM Where id
    EstudianteMateriaseDTO dbStudent = DB.Single(est => est.Id == id);

    List<string> MateriasN = dbStudent.Materias.ToList();

    foreach(string materia in esDto.Materias) {
        if (MateriasN.IndexOf(materia) == -1) {
            MateriasN.Add(materia);
        }
    }
    
    dbStudent.Materias = MateriasN.ToArray();
});

app.Run();


public class EstudianteMateriaseDTO
{
    public int Id {get; set;}
    public string[] Materias {get; set;}
}