﻿
//Parctiaca de ciclos 
//numeros positivos no ,y divicion por cero no 

int opc = 0;
String menu = "1) Sumar\n2) Restar\n3) Multiplicar\n4) Dividir\n0) Salir";

do

{
    Console.WriteLine("Ingrese una opción \n" + menu);
    opc = Int32.Parse(Console.ReadLine());
    int num1 = 0;
    int num2 = 0;

    if (opc != 0)
    {
        Console.WriteLine("Ingrese el número 1");
        num1 = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese el número 2");
        num2 = Int32.Parse(Console.ReadLine());

        if (num1 > 0 || num2 > 0)
        {
            switch (opc)
            {
                case 1:
                    Console.WriteLine("****************************************");
                    Console.WriteLine("El resultado de la suma es " + (num1 + num2));
                    Console.WriteLine("****************************************\n");
                    break;
                case 2:
                    Console.WriteLine("****************************************");
                    Console.WriteLine("El resultado de la resta es " + (num1 - num2));
                    Console.WriteLine("****************************************\n");
                    break;
                case 3:
                    Console.WriteLine("****************************************");
                    Console.WriteLine("El resultado de la multiplicación es " + (num1 * num2));
                    Console.WriteLine("****************************************\n");
                    break;
                case 4:
                    if (num2 == 0)
                    {
                        Console.WriteLine("No se puede divivir por cero\n Ingrese otro valor: ");
                        num2 = Int32.Parse(Console.ReadLine());
                        if (num2 != 0)
                        {
                            Console.WriteLine("****************************************");
                            Console.WriteLine("El resultado de la Divicion es " + (num1 / num2));
                            Console.WriteLine("****************************************\n");
                        }
                        else
                        {
                            Console.WriteLine("Imposible dividir por cero");
                        }
                    }
                    break;
                case 0:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Opción no valida");
                    break;
            }
        }
        else
        {
            Console.WriteLine("Solo se aceptan números positivos");
        }
    }

} while (opc != 0);


