using SerieAPI.Class;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

Serie Serie = new Serie();

app.MapPost("/api/v1/serie", (SerieDTO serie) => {
    Serie.Add(serie);
}); 

app.MapGet("/api/v1/serie", () => {
    return Results.Ok(Serie.All());
});

app.Run();
