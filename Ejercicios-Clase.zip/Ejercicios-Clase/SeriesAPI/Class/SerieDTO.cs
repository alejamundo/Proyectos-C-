namespace SerieAPI.Class;

public class SerieDTO
{
    public int Id {set; get;}    
    public string Titulo {set; get;}
    public string Genero {set; get;}
    public string Director {set; get;}
    public int NroTemporadas {set; get;}    
}