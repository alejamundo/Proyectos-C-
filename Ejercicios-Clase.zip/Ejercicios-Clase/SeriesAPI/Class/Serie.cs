namespace SerieAPI.Class;

public class Serie : ISerie
{
    private List<SerieDTO> BD;

    public Serie ()
    {
        this.BD = new List<SerieDTO>();
    }

    public void Add(SerieDTO Serie)
    {
        this.BD.Add(Serie);
    }

    public void Delete(int id)
    {
        this.BD.RemoveAll(serie => serie.Id == id);
    }

    public void Update(int id, SerieDTO Serie)
    {
        SerieDTO serieUpdate = this.BD.Single(serie => serie.Id == id);
        serieUpdate = Serie;
    }

    public List<SerieDTO> All()
    {
        return this.BD;
    }
}