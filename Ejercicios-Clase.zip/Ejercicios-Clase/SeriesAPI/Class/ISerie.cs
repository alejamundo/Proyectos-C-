namespace SerieAPI.Class;

interface ISerie
{
    void Add(SerieDTO Serie);
    void Delete(int id);
    void Update(int id, SerieDTO Serie);
    List<SerieDTO> All();
}