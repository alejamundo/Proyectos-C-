﻿//en un vector guardar la informacion de personas que cumplen años en cada mes
//esta informacion se agrega atraves de la consola
//Al final mostrar la cantidad de personas que cumplen años encada mes
//mostrar los meses con mas personas o menos

String[] meses={"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
String mes="";
int cantidad_cumpleañeros;
int[] vector=new int[12];
int mayor=0;
int menor=1000;
String[] mesesMayores=new String[12];
String[] mesesMenores=new String[12];
String mayores="";
String menores="";

for (int i = 0; i < 12; i++)
{
    mes=meses[i];
    Console.WriteLine("Ingrese Cuantas personas Cumplen años en: "+mes);
    cantidad_cumpleañeros=Int32.Parse(Console.ReadLine());
    vector[i]=cantidad_cumpleañeros;
}

for (int i = 0; i < 12; i++)
{
    mes=meses[i];
    Console.WriteLine("Las personas que cumplen en: "+mes+" son: "+vector[i]);
}

//meses mayores
for (int i = 0; i < 12; i++)
{
    if (vector[i]>mayor)
    {
        mayor=vector[i];
    }

}

for (int i = 0; i < 12; i++)
{
    if (vector[i]==mayor)
    {
        mesesMayores[i]=meses[i];
    }
}

for (int i = 0; i < 12; i++)
{

    mayores=mayores + mesesMayores[i];
}

//meses menores
for (int i = 0; i < 12; i++)
{
    if (vector[i]<menor)
    {
        menor=vector[i];
    }

}

for (int i = 0; i < 12; i++)
{
    if (vector[i]==menor)
    {
        mesesMenores[i]=meses[i]+" ";
    }
}

for (int i = 0; i < 12; i++)
{

    menores=menores + mesesMenores[i]+" ";
}
Console.WriteLine("**********************");
Console.WriteLine("Mes Menor: "+menores+" Cantidad: "+menor);
Console.WriteLine("Mes Mayor: "+mayores+" Cantidad: "+mayor);
Console.WriteLine("**********************");
