namespace parctica_poo;

public interface Ifugura{
    public int basse {get;set;}
    public int altura {get;set;}

    public int area();
    public int perimetro();

}