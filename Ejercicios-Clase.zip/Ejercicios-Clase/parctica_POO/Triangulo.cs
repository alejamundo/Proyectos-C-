namespace parctica_poo;
class Triangulo : Ifugura
{
    public Triangulo(int basse,int altura)
    {
        this.basse=basse;
        this.altura=altura;
    }

    public int basse { get; set; }
    public int altura { get; set; }

    public int area()
    {
        return (this.basse*this.altura)/2;
    }

    public int perimetro()
    {
        return (this.altura*2)+this.basse;
    }
}