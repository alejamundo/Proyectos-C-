namespace parctica_poo;

public abstract class rectangulo : Ifugura
{
    public int basse { get; set; }
    public int altura { get; set; }
    public int area()
    {
        return this.basse * altura;
    }
    public int perimetro()
    {
        return (this.basse + this.altura) * 2;
    }

}