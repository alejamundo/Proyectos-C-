﻿//propiedades de un objeto
//estado puede cambiar en el tiempo
//comportamiento acciones
//identidad que sea unico
//namespaces encapsular todo un proyecto

//clase normal se pueden crear objetos, clase abstracta no se puede instanciar

using parctica_poo;

Cuadrado cuadrado=new Cuadrado();
cuadrado.basse=10;
cuadrado.altura=10;

Console.WriteLine("El area del cuadrado es: "+cuadrado.area());

Triangulo triangulo=new Triangulo(5,5);
Console.WriteLine("El area del triangulo es: "+triangulo.area());