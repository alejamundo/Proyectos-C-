namespace parctica_poo;
//using parctica_poo //para importar clases o todo el espacio
class Cuadrado:rectangulo
{
    
}