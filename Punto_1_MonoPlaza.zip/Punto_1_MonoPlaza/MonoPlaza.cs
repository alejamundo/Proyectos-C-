namespace Punto_1_MonoPlaza;

public abstract class MonoPlaza : IVehiculo
{ 
    private String escuderia;
    private bool encendido;
    private bool en_movimiento;

    public MonoPlaza(String escuderia)
    {
        this.escuderia = escuderia;
        this.encendido = false;
        this.en_movimiento = false;
    }

    public void Encender()
    {
        if (encendido == false)
        {
            encendido = true;
            Console.WriteLine("El vehículo se Encendió");
        }
        else
        {
            Console.WriteLine("El vehículo ya está Encendido :)");
        }
        
    }

    public void Apagar()
    {
        if (encendido == true && en_movimiento == false)
        {
            encendido = false;
            Console.WriteLine("El vehículo se Apago");
        }
        else if (en_movimiento)
        {
            Console.WriteLine("El vehículo no se puede Apagar, esta en Movimiento :(");
        }
        else
        {
            Console.WriteLine("El vehículo ya está Apagado :)");
        }
    }

    public void Detener()
    {
        if (encendido == true && en_movimiento == true)
        {
            en_movimiento = false;
            Console.WriteLine("El vehículo se a Detenido");
        }
        else if (en_movimiento==false)
        {
            Console.WriteLine("El vehículo ya esta Detenido :)");
        }
        else
        {
            Console.WriteLine("El vehículo no esta encendido, 'No se puede Detener':(");
        }
    }

    public void Movimiento()
    {
        if (encendido == true && en_movimiento == false)
        {
            en_movimiento = true;
            Console.WriteLine("El vehículo se está Moviendo");
        }
        else if (encendido==false)
        {
            Console.WriteLine("El vehículo está Apagado :(");
        }
        else
        {
            Console.WriteLine("El vehículo ya esta en Movimiento :)");
        }
    }
}