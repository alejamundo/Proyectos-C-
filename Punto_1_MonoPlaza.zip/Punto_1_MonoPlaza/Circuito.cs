namespace Punto_1_MonoPlaza;

public class Circuito
{
    private String nombre;
    private int n_vueltas;
    //objeto monoplaza
    MonoPlaza mp;
    public Circuito(string nombre, int n_vueltas)
    {
        this.nombre = nombre;
        this.n_vueltas = n_vueltas;
        this.mp=null;
    }

    public void Agregar(MonoPlaza monoPlaza){
        if (this.mp==null)
        {
            //no hay monoplaza en el circuito
            this.mp=monoPlaza;
        }
    }
    public void Sacar(){
        if (this.mp!=null)
        {
            //hay un monoplazo en el circuito
            this.mp=null;
        }
    }
    public void Prueba(){
        if (this.mp!=null)
        {//hay un monoplazo en el circuito
            //Antes de comenzar prueba inicio monoplazo apagado
            mp.Detener();
            mp.Apagar();
            int[] tiempo_vuelta=new int[n_vueltas];//Almaceno tiempos de cada vuelta
            int tiempo;
            Random aleatorio=new Random();
            int menor_tiempo=999999;//inicializo con valor mas alto posible
            
            //enciendo el monoplazo para comenzar carrera y lo pongo en movimiento
            mp.Encender();
            mp.Movimiento();
            for (int i = 0; i < n_vueltas; i++)
            {
                tiempo=aleatorio.Next(100000,999999);
                tiempo_vuelta[i]=tiempo;
                //imprimer tiempo en cada vuelta
                Console.WriteLine($"Vuelta número {i+1}: Tiempo transcurrido: {tiempo_vuelta[i]}");
                if (tiempo_vuelta[i]< menor_tiempo)
                {
                    menor_tiempo=tiempo_vuelta[i];//almaceno el mejor tiempo
                }
            }
            //pago monoplazo al finalizar vueltas
            mp.Detener();
            mp.Apagar();
            Console.WriteLine("El mejor tiempo de este circuito es de: "+menor_tiempo); 

            //entregar tabla de pocisiones de menor a mayor tiempo
            Array.Sort(tiempo_vuelta);//ordeno arreglo
            Console.WriteLine("*************************************");
            Console.WriteLine("\nTabla de posiciones de menor a mayor tiempo");
            string salida="\t------Tiempo\n";
            for (int i = 0; i < tiempo_vuelta.Length; i++)
            {
                salida+=$"\t------{tiempo_vuelta[i]}\n";
            }
            Console.WriteLine(salida);
        }
    }
}