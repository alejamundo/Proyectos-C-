namespace Punto_1_MonoPlaza;

public interface IVehiculo
{
    //Creo los metodos que tienen todos los monoplaza
    public void Encender();
    public void Apagar();
    public void Detener();
    public void Movimiento();
}