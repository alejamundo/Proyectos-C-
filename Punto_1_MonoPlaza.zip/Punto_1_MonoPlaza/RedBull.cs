namespace Punto_1_MonoPlaza;

public class RedBull : MonoPlaza
{
    private String escuderia;
    public RedBull(string escuderia) : base(escuderia)
    {
        this.escuderia=escuderia;
    }
}