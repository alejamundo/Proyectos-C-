namespace Punto_1_MonoPlaza;

public class MClaren : MonoPlaza
{
    private String escuderia;
    public MClaren(string escuderia) : base(escuderia)
    {
        this.escuderia=escuderia;
    }
}