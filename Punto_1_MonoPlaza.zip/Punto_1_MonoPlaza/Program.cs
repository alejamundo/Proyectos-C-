﻿using Punto_1_MonoPlaza;

//Probar RedBull
RedBull mp1=new RedBull("Formula 1");
//prueba de circuito
Circuito c1=new Circuito("Twin Ring Moteg",5);
c1.Agregar(mp1);
c1.Prueba();

Ferrari mp2=new Ferrari("Formula 1");
c1.Agregar(mp2);//no se puede dos monoplazos en un circuito
