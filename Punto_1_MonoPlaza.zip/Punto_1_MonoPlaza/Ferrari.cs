namespace Punto_1_MonoPlaza;

public class Ferrari : MonoPlaza
{
    private String escuderia;
    public Ferrari(string escuderia) : base(escuderia)
    {
        this.escuderia=escuderia;
    }
}