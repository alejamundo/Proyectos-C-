namespace examen;

public class Jugo : Ifruta
{
    public void getCantidad(int cantidad)
    {
        Console.WriteLine("Cantidad de Fruta: "+cantidad);
    }
    public void getNombre(string nombre)
    {
        Console.WriteLine("Nombre del jugo: "+nombre);
    }
    public void valorJugo(int valor,int cantidad_jugos){
        Console.WriteLine("Valor total : "+valor*cantidad_jugos);
    }
}