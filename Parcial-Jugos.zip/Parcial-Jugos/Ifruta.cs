namespace examen;   

public interface Ifruta{
    public void getNombre(string nombre);
    public void getCantidad(int cantidad);
    
}