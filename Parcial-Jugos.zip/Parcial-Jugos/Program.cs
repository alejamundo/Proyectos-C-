﻿/*Se necesita un programa que indique el nombre del jugo que se va preparar 
y la cantidad de fruta que se va usar en el jugo, además debe permitir saber cuánto cuesta 1 o n cantidad de jugos

Nota: La cantidad de fruta no influye en el precio del jugo.
Requisitos:
Se debe usar 1 clase
Se debe usar una interfaz*/
using examen;

string nombre;
int cantidad;
int valor = 5000;
int cantidad_jugos;

Console.WriteLine("Bienvenido a nuestra tienda de Jugos");

Console.WriteLine("Indica el Nombre del jugo que deseas");
nombre = Console.ReadLine();

Console.WriteLine("Indica la cantidad de Fruta que se va a utilizar");
cantidad = Int32.Parse(Console.ReadLine());

Console.WriteLine("Indica La cantidad de jugos que desea");
cantidad_jugos = Int32.Parse(Console.ReadLine());

//Resultado
Jugo j1=new Jugo();

j1.getNombre(nombre);
j1.getCantidad(cantidad);
j1.valorJugo(valor,cantidad_jugos);







