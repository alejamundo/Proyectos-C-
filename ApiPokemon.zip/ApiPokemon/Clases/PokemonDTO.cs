namespace ApiPokemon;

class PokemonDTO
{
    public int id { get; set; }
    public string nombre { get; set; }
    public string tipo { get; set; }
    public List<int> habilidades { get; set; }
    public double defensa { get; set; }
}
    
