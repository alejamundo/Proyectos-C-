namespace ApiPokemon;

interface Ipokemon
{
    //1.	Para crear 1 pokémon
    public void crear1(PokemonDTO pokemon);
    //2.	Para crear múltiples pokemones
    public void crearAll(PokemonDTO[] pokemones);
    //3.	Para editar 1 pokémon
    public void edit1(int id, PokemonDTO pokemon);
    //4.	Para eliminar 1 pokémon
    public void elimina1(int id);
    //5.	Para traer 1 pokémon
    public PokemonDTO get1(int id);
    //6.	Para traer todos los pokemones de un tipo
    public List<PokemonDTO> getType(string tipo);

    //*************************Adicionales***************************************************
    //Creados por Aleja
    public List<PokemonDTO> getAll();
    public void eliminaUltimo();

    //Creados Por Juan
    public List<PokemonDTO> getNombre(string nombre);
    public List<PokemonDTO> getDefensa(double defensa);

    // Creados Por Cristian
    public void DelAllByType(string tipo);
    public void eliminarTodos();

    // Creados Por Yureizon
    public  List<PokemonDTO> AllSameType(string tipo);
    public List<PokemonDTO> AllSameAttributes(PokemonDTO pkb);

}