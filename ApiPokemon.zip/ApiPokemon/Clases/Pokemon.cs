namespace ApiPokemon;

class Pokemon : Ipokemon
{
    //Creo base de datos e inicializo
    private List<PokemonDTO> memoriaBD;
    public Pokemon()
    {
        this.memoriaBD = new List<PokemonDTO>();
    }

    //1.	Para crear 1 pokémon
    public void crear1(PokemonDTO pokemon)
    {
        this.memoriaBD.Add(pokemon);
    }

    //2.	Para crear múltiples pokemones
    public void crearAll(PokemonDTO[] pokemones)
    {
        foreach (PokemonDTO pk in pokemones)//recorro cada uno de los objetos
        {
            this.memoriaBD.Add(pk);//agregame cada uno a la memoria
        }
    }

    //3.	Para editar 1 pokémon
    public void edit1(int id, PokemonDTO pokemon)
    {
        PokemonDTO pokemonUpdate = this.memoriaBD.Single(pokemon => pokemon.id == id);
        // Actualizar los campos de pokemonUpdate con los valores de pokemon
        pokemonUpdate.nombre = pokemon.nombre;
        pokemonUpdate.tipo = pokemon.tipo;

        bool skill_Correctos = true;
        bool defensa_correcta = false;
        //compruebo que las habilidades esten en el rango indicado y sean numeros enteros
        foreach (var skill in pokemon.habilidades)
        {
            if (skill >= 0 && skill <= 40 && skill_Correctos && skill is int)
            {
                skill_Correctos = true;
            }
            else
            {
                skill_Correctos = false;
            }
        }
        //compruebo que la defenza este en el rango y sean numeros float
        if (pokemon.defensa >= 1 && pokemon.defensa <= 30 && pokemon.defensa is double)
        {
            defensa_correcta = true;
        }

        if (skill_Correctos && defensa_correcta)
        {
            pokemonUpdate.habilidades = pokemon.habilidades;
            pokemonUpdate.defensa = pokemon.defensa;
            this.memoriaBD[id - 1] = pokemonUpdate;
            return;
        }

        this.memoriaBD[id - 1] = pokemonUpdate;
    }

    //4.	Para eliminar 1 pokémon
    public void elimina1(int id)
    {   //elimina el objeto que lleve ese id
        this.memoriaBD.RemoveAll(pokemon => pokemon.id == id);
    }

    //5.	Para traer 1 pokémon
    public PokemonDTO get1(int id)
    {
        //mostrar solo el objeto que cumpla con id
        PokemonDTO opten1 = this.memoriaBD.Single(pokemon => pokemon.id == id);
        return opten1;
    }

    //6.	Para traer todos los pokemones de un tipo
    public List<PokemonDTO> getType(string tipo)
    {
        var datosSegunTipo = this.memoriaBD.Where(pokemon => pokemon.tipo == tipo);
        //convertir a list
        List<PokemonDTO> listaFiltrada = datosSegunTipo.ToList();
        return listaFiltrada;
    }

    //*************************Adicionales***************************************************
    //Creados por Aleja
    public List<PokemonDTO> getAll()
    {
        return this.memoriaBD;
    }
    public void eliminaUltimo()
    {
        if (this.memoriaBD.Count > 0)
        {//si hay datos me elimina el ultimo
            this.memoriaBD.RemoveAt(this.memoriaBD.Count - 1);
        }
    }

    //Creador por Juan
    public List<PokemonDTO> getNombre(string nombre)
    {
        var datosSegunNombre = this.memoriaBD.Where(pokemon => pokemon.nombre == nombre);
        //convertir a list
        List<PokemonDTO> listaFiltrada = datosSegunNombre.ToList();
        return listaFiltrada;
    }
    public List<PokemonDTO> getDefensa(double defensa)
    {
        var datosSegunDefensa = this.memoriaBD.Where(pokemon => pokemon.defensa == defensa);
        //convertir a list
        List<PokemonDTO> listaFiltrada = datosSegunDefensa.ToList();
        return listaFiltrada;
    }

    // Creados Por Cristian
    public void eliminarTodos()
    {
        this.memoriaBD.Clear();
    }
    public void DelAllByType(string tipo)
    {
        this.memoriaBD.RemoveAll(pokemon => pokemon.tipo == tipo);
    }
    // Creados Por Yureizon
    public List<PokemonDTO> AllSameType(string tipo)
    {
        foreach (PokemonDTO pk in this.memoriaBD)
        {
            pk.tipo = tipo;
        }
        return this.memoriaBD;
    }

    public List<PokemonDTO> AllSameAttributes(PokemonDTO pkb)
    {
        foreach (PokemonDTO pk in this.memoriaBD)
        {
            pk.nombre = pkb.nombre;
            pk.tipo = pkb.tipo;
            pk.habilidades = pkb.habilidades;
            pk.habilidades = this.correctValues(pkb.habilidades);
            if (pkb.defensa <= 30 && pkb.defensa > 0) { pk.defensa = pkb.defensa; }
            if (pkb.defensa > 30) { pk.defensa = 30; }
            if (pkb.defensa < 1) { pk.defensa = 1; }
        }
        return this.memoriaBD;
    }
   


    // Metodo para validar que los valores de las habilidades sean correctos.
    public List<int> correctValues(List<int> h)
    {
        List<int> easy = new List<int>();
        foreach (int x in h)
        {
            if (x >= 0 && x <= 40) { easy.Add(x); }
            if (x < 0) { easy.Add(0); }
            if (x > 40) { easy.Add(40); }
        }
        return easy;
    }
}