using ApiPokemon;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();
Pokemon pk = new Pokemon();


//1.	Para crear 1 pokémon
app.MapPost("/api/v1/pk/crear1", (PokemonDTO pokemon) =>
{
    bool skill_Correctos = true;
    bool defensa_correcta = false;
    //compruebo que las habilidades esten en el rango indicado y sean numeros enteros
    foreach (var skill in pokemon.habilidades)
    {
        if (skill >= 0 && skill <= 40 && skill_Correctos && skill is int)
        {
            skill_Correctos = true;
        }
        else
        {
            skill_Correctos = false;
        }
    }
    //compruebo que la defenza este en el rango y sean numeros float
    if (pokemon.defensa >=1 && pokemon.defensa <=30 && pokemon.defensa is double)
    {
        defensa_correcta=true;
    }

    //si cumple las condiccines agrego el pokemon
    if (skill_Correctos && defensa_correcta)
    {
        pk.crear1(pokemon);
        return Results.Ok("Se agrego un nuevo pokemon Correctamente");
    }
    //si no cumple no agrega pokemon y envia error por no ser del tipo o este mensaje por no estar en el rango
    return Results.Ok("No se pudo agregar correctamente el pokemon --No se cumple con los requisitos en las habilidades o defensa");
});
//************************************************************************************

//2.	Para crear múltiples pokemones
app.MapPost("/api/v1/pk/crearAll", (PokemonDTO[] pokemones) =>
{
    foreach (var pokemon in pokemones)
    {
        pk.crear1(pokemon);
    }
    return Results.Ok("Se agregaron los pokemones que cumplieron los requisitos") ;
});
//************************************************************************************

//3.	Para editar 1 pokémon
app.MapPut("/api/v1/pk/edit1/{id}", (PokemonDTO pokemon, int id) => {
    pk.edit1(id,pokemon);
    return  Results.Ok("Se Actualizo un Pokemon (Si las habilidades y la defensa no son correctas a la vez estas no se actualizaran)");
});
//************************************************************************************

//4.	Para eliminar 1 pokémon
app.MapDelete("/api/v1/pk/elimina1/{id}", (int id) => {
    pk.elimina1(id); 
    return  Results.Ok("Si el pokemon estaba, se Elimino el del id: "+id);
});
//************************************************************************************

//5.	Para traer 1 pokémon
app.MapGet("/api/v1/pk/get1/{id}", (int id) =>
{
    return Results.Ok(pk.get1(id));
});
//************************************************************************************

//6.	Para traer todos los pokemones de un tipo
app.MapGet("/api/v1/pk/gettype/{tipo}", (string tipo) =>
{
    return Results.Ok(pk.getType(tipo));
});

//*************************Adicionales***************************************************
//Creados Aleja
//Mostrar Todos los pokemones
app.MapGet("/api/v1/pk/getAll", () =>
{
    return Results.Ok(pk.getAll());
});

//Eliminar el ultimo pokemon
app.MapDelete("/api/v1/pk/eliminaUlt", () => {
    pk.eliminaUltimo();
    return  Results.Ok("Si habian Pokemones creados se elimino el ultimo");
});
//************************************************************************************

//Creados Juan
//Mostrar todos segun el Nombre
app.MapGet("/api/v1/pk/getnombre/{nombre}", (string nombre) =>
{
    return Results.Ok(pk.getNombre(nombre));
});

//Mostrar todos segun la defensa
app.MapGet("/api/v1/pk/getdefensa/{defensa}", (double defensa) =>
{
    return Results.Ok(pk.getDefensa(defensa));
});

// Creados Yureizon
// Asignar un mismo tipo a todos
app.MapPut("/api/v1/pk/allsametype/{tipo}", (string tipo) => 
{
    return Results.Ok(pk.AllSameType(tipo));
});

// Asignar los mismos atributos a todos
app.MapPut("/api/v1/pk/allsameattributes", (PokemonDTO pkb) => 
{
   
    string salida = "Done. ";
    salida = salida +" En caso de haber valores por fuera de los limites";
    salida = salida +" estos valores fueron sustituidos por el valor maximo o minimo,";
    salida = salida +" según corresponda el caso.";
    return Results.Ok(salida+"\n"+ pk.AllSameAttributes(pkb));
});

// Creados Cristian
// Eliminar Todos los Pokemons
app.MapDelete("/api/v1/pk/delall", () => 
{
    pk.eliminarTodos();
    return Results.Ok(pk.getAll());
});

// Eliminar Todos los Pokemos de un Tipo
app.MapDelete("/api/v1/pk/delall/{tipo}", (string tipo) => 
{
    pk.DelAllByType(tipo);
    return Results.Ok(pk.getAll());
});



//************************************************************************************

app.Run();
/*
--------Datos de prueba-----------

[{
    "id": 1,
    "nombre": "Pikachu",
    "tipo": "Elétrico",
    "habilidades": [4, 20, 32, 40],
    "defensa": 29.5
},
{
    "id": 2,
    "nombre": "Eevee",
    "tipo": "Normal",
    "habilidades": [8, 2, 30, 23],
    "defensa": 19.5
}
,
{
    "id": 3,
    "nombre": "Eevee",
    "tipo": "Normal",
    "habilidades": [8, 2, 30, 40],
    "defensa": 4.5
}
,
{
    "id": 4,
    "nombre": "Lori",
    "tipo": "Normal",
    "habilidades": [8, 2, 30, 20],
    "defensa": 19.5
}]

*/